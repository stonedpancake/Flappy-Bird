# FlappyBird
flip flap flop flup

Well, I guess everybody knows Flappy Bird. Here we have same old Flappy Bird but in retro wave style and with a shop.

More about functional:
  Shop: here u can buy themes, cheats (no), birds (later) and other EXTREMELY IMPORTANT things.
  Authorization: u can also log into in game to save your results, purchases and (later) to compare with other players.
Enjoy :D
