import sys

import pygame
from pygame import init, display, image, Rect, time, QUIT, KEYDOWN, K_SPACE, K_RIGHT, K_LEFT, K_UP, K_DOWN, draw, MOUSEBUTTONDOWN

from Statements import bg_color, columns_color

SIZE = WIDTH, HEIGHT = 1920, 1080


class Settings:

    def __init__(self):

        init()
        self.screen = display.set_mode(SIZE)

        self.menu_image = image.load("./Data/Pictures/Menu_6.png")
        self.settings_1 = image.load("./Data/Pictures/Settings_1_1.png")
        self.color_doc = image.load("./Data/Pictures/color_doc_2.png")

        self.quit_btn_rect = Rect(760, 220, 65, 30)
        self.columns_btn = Rect(810, 340, 70, 15)
        self.sprite_btn = Rect(810, 380, 45, 15)
        self.background_btn = Rect(810, 417, 95, 15)

        self.light_purple_bnt = Rect(947.5, 372.5, 25, 25)
        self.light_blue_bnt = Rect(982.5, 372.5, 25, 25)
        self.light_green_bnt = Rect(1017.5, 372.5, 25, 25)
        self.dark_yellow_bnt = Rect(1052.5, 372.5, 25, 25)
        self.coral_bnt = Rect(1087.5, 372.5, 25, 25)

    def btn_boxes(self):

        draw.rect(self.screen, 'coral', self.quit_btn_rect, 1)
        draw.rect(self.screen, 'coral', self.columns_btn, 1)
        draw.rect(self.screen, 'coral', self.sprite_btn, 1)
        draw.rect(self.screen, 'coral', self.background_btn, 1)

        draw.rect(self.screen, 'coral', self.light_purple_bnt, 1)
        draw.rect(self.screen, 'coral', self.light_blue_bnt, 1)
        draw.rect(self.screen, 'coral', self.light_green_bnt, 1)
        draw.rect(self.screen, 'coral', self.dark_yellow_bnt, 1)
        draw.rect(self.screen, 'coral', self.coral_bnt, 1)

    def color_doc_func(self, obj):

        exit_ = False

        while not exit_:

            self.screen.blit(self.color_doc, (940, 365))
            self.btn_boxes()
            display.flip()

            for event in pygame.event.get():

                if event.type == QUIT:
                    exit_ = True

                if event.type == MOUSEBUTTONDOWN:

                    if self.quit_btn_rect.collidepoint(event.pos):
                        exit_ = True

                    if obj == 'columns':

                        if self.light_purple_bnt.collidepoint(event.pos):
                            columns_color('#EAA6E5')

                        if self.light_blue_bnt.collidepoint(event.pos):
                            columns_color('#56ACDD')

                        if self.light_green_bnt.collidepoint(event.pos):
                            columns_color('#80C6A0')

                        if self.dark_yellow_bnt.collidepoint(event.pos):
                            columns_color('#DDA756')

                        if self.coral_bnt.collidepoint(event.pos):
                            columns_color('#FF7F50')

                    if obj == 'columns':

                        if self.light_purple_bnt.collidepoint(event.pos):
                            bg_color('#EAA6E5')

                        if self.light_blue_bnt.collidepoint(event.pos):
                            bg_color('#56ACDD')

                        if self.light_green_bnt.collidepoint(event.pos):
                            bg_color('#80C6A0')

                        if self.dark_yellow_bnt.collidepoint(event.pos):
                            bg_color('#DDA756')

                        if self.coral_bnt.collidepoint(event.pos):
                            bg_color('#FF7F50')
            pygame.quit()

    def run(self):

        exit_ = False
        clock = time.Clock()

        color_doc = False
        obj = None

        while not exit_:

            clock.tick(60)

            self.screen.blit(self.menu_image, (0, 0))
            self.screen.blit(self.settings_1, (760, 220))
            self.btn_boxes()

            if color_doc:
                self.color_doc_func(obj)

            display.flip()

            for event in pygame.event.get():

                if event.type == QUIT:
                    exit_ = True

                if event.type == MOUSEBUTTONDOWN:

                    if self.quit_btn_rect.collidepoint(event.pos):
                        exit_ = True

                    if self.columns_btn.collidepoint(event.pos):
                        color_doc = True
                        obj = 'columns'

                    if self.background_btn.collidepoint(event.pos):
                        color_doc = True
                        obj = 'bg'
