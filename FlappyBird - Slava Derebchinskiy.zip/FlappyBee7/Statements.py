def bg_color(colour='black'):
    return colour


def columns_color(colour='white'):
    return colour


BG_COLOR = bg_color()
COLUMNS_COLOR = columns_color()
