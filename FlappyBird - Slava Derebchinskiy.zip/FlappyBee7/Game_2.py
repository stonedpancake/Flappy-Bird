from random import choice
import pygame
from pygame import init, display, image, Rect, time, QUIT, KEYDOWN, K_SPACE, K_RIGHT, K_LEFT, K_UP, K_DOWN, draw, Color, transform, MOUSEBUTTONDOWN
from pygame.font import Font

import Main
import Shop
from Statements import COLUMNS_COLOR, BG_COLOR

SIZE = WIDTH, HEIGHT = 1920, 1080


class Game:

    def __init__(self):

        init()
        self.start = False
        self.score = 0
        self.screen = display.set_mode(SIZE)

        self.column_color = COLUMNS_COLOR
        self.bg_color = BG_COLOR
        self.hit_box_color = Color('pink')  # SQLITE

        self.font = Font('./Data/Fonts/Futurespore.otf', 100)
        self.score_text = self.font.render(str(self.score), True, Color('white'))
        self.str_score = str(self.score)
        self.q_score_q = self.font.render('Score:', True, Color('white'))

        self.show_hit_box = False

        self.sprite_img = image.load("./Data/Sprites/angel_purple.png")
        self.sprite_x, self.sprite_y = 50, 520
        self.sprite_box = Rect(self.sprite_x, self.sprite_y, *self.sprite_img.get_size())

        self.column_x = 1980
        self.column_speed = 5
        self.column_height = choice(range(300, 700, 10))
        self.upd_column_y = self.column_height + 100
        self.upd_column_height = HEIGHT - self.upd_column_y
        self.column_rect = Rect(self.column_x, 0, 90, self.column_height)
        self.upd_column_rect = Rect(self.column_x, self.upd_column_y, 90, self.upd_column_height)

        self.game_over_image = image.load("./Data/Pictures/Game_Over_red_violet_linear.png")
        self.home_btn = Rect(875, 540, 40, 40)
        self.play_btn = Rect(940, 540, 40, 40)
        self.shop_btn = Rect(1005, 540, 40, 40)

    def general_columns(self):

        self.update('sprite')

        # draw.rect(self.screen, Color('black'), self.sprite_box, 0)
        self.screen.fill(Color('black'), self.sprite_box)
        self.screen.blit(self.sprite_img, (self.sprite_x, self.sprite_y))

        if self.start and not self.dead():

            self.sprite_y += 1.2

            if self.column_x + 90 < 0:
                self.column_x = 1980
                self.update('columns')

            self.screen.blit(self.sprite_img, (self.sprite_x, self.sprite_y))
            # draw.rect(self.screen, Color('pink'), self.sprite_box, 2)

            self.column_x -= self.column_speed

            self.column_rect = Rect(self.column_x, 0, 90, self.column_height)
            self.upd_column_rect = Rect(self.column_x, self.upd_column_y, 90, self.upd_column_height)

            draw.rect(self.screen, self.column_color, self.column_rect, 0)
            draw.rect(self.screen, self.column_color, self.upd_column_rect, 0)

            if self.show_hit_box:
                self.draw_hit_box()

    def single_columns(self):

        self.update('sprite')

        self.screen.fill(self.bg_color)
        self.screen.blit(self.sprite_img, (self.sprite_x, self.sprite_y))

        if self.start and not self.dead():

            self.sprite_y += 1.2

            if self.column_x + 90 < 0:
                self.column_x = 1980
                self.update('columns')

            self.screen.blit(self.sprite_img, (self.sprite_x, self.sprite_y))
            # draw.rect(self.screen, Color('pink'), self.sprite_box, 2)

            self.column_x -= 5

            self.column_rect = Rect(self.column_x, 0, 90, self.column_height)
            self.upd_column_rect = Rect(self.column_x, self.upd_column_y, 90, self.upd_column_height)

            if self.sprite_x + self.sprite_box.width > self.column_x + self.column_rect.width:
                self.score += 1 / 20

            draw.rect(self.screen, self.column_color, self.column_rect, 0)
            draw.rect(self.screen, self.column_color, self.upd_column_rect, 0)

            if self.score > 0:
                self.str_score = str(self.score)[0:str(self.score).find('.')]

            self.score_text = self.font.render(self.str_score, True, Color('white'))
            self.screen.blit(self.q_score_q, (960 - self.score_text.get_width() // 2 - 10, 10))
            self.screen.blit(self.score_text, (960 - self.score_text.get_width() // 2 + self.q_score_q.get_width(), 10))

            if not int(self.str_score) % 2:
                self.column_speed += int(self.str_score) // 1

            display.flip()

            if self.show_hit_box:
                self.draw_hit_box()

    def update(self, box='all'):

        if box == 'sprite':
            self.sprite_box = Rect(self.sprite_x, self.sprite_y, *self.sprite_img.get_size())

        if box == 'columns':
            self.column_height = choice(range(300, 700, 10))
            self.upd_column_y = self.column_height + 100
            self.upd_column_height = HEIGHT - self.upd_column_y
            self.upd_column_rect = Rect(self.column_x, self.upd_column_y, 90, self.upd_column_height)

        if box == 'all':
            self.sprite_box = Rect(self.sprite_x, self.sprite_y, *self.sprite_img.get_size())
            self.column_height = choice(range(300, 700, 10))
            self.upd_column_y = self.column_height + 100
            self.upd_column_height = HEIGHT - self.upd_column_y
            self.column_rect = Rect(self.column_x, 0, 90, self.column_height)
            self.upd_column_rect = Rect(self.column_x, self.upd_column_y, 90, self.upd_column_height)

    def draw_hit_box(self):

        draw.rect(self.screen, self.hit_box_color, self.column_rect, 0)
        draw.rect(self.screen, self.hit_box_color, self.upd_column_rect, 0)

    def dead(self):

        if self.column_rect.colliderect(self.sprite_box) or self.upd_column_rect.colliderect(self.sprite_box):
            self.game_over()
            return True

        if self.sprite_y >= HEIGHT:
            self.game_over()
            return True

        return False

    def game_over(self):

        self.screen.blit(self.game_over_image, (810, 465))

        exit_ = False
        clock = time.Clock()

        while not exit_:

            clock.tick(60)
            self.screen.blit(self.game_over_image, (810, 465))
            display.flip()

            for event in pygame.event.get():

                if event.type == QUIT:
                    exit_ = True

                if event.type == MOUSEBUTTONDOWN:

                    if self.home_btn.collidepoint(event.pos):
                        Main.Main().run()

                    if self.play_btn.collidepoint(event.pos):
                        Game().run()

                    if self.shop_btn.collidepoint(event.pos):
                        Shop.Shop().run()

    def run(self):

        exit_ = False
        clock = time.Clock()

        while not exit_:

            clock.tick(60)
            self.single_columns()
            display.flip()

            for event in pygame.event.get():

                if event.type == QUIT:
                    exit_ = True

                if event.type == KEYDOWN:

                    if event.key == K_SPACE:

                        self.start = True

                        if not self.dead():
                            self.sprite_y -= 20
